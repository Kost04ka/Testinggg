package com.example.autocopyusb;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Toast;
import androidx.documentfile.provider.DocumentFile;
import android.content.SharedPreferences;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int PICK_SOURCE = 10;
    private static final int PICK_DEST = 11;
    private TextView status;
    private Uri sourceUri, destUri;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        sourceUri = readUri("source");
        destUri = readUri("dest");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 28, 28, 28);
        layout.setGravity(Gravity.TOP);

        TextView title = new TextView(this);
        title.setText("AutoCopyUSB — тестовая версия");
        title.setTextSize(23);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("\n1) Выбери корневую папку USB-флешки.\n2) Выбери папку назначения во внутренней памяти.\n3) Нажми «Копировать сейчас».\n\nЭта сборка проверяет доступ к файлам. Автоматическое обнаружение подключения USB пока не реализовано.");
        info.setTextSize(16);
        layout.addView(info);

        Button src = new Button(this);
        src.setText("Выбрать папку флешки");
        src.setOnClickListener(v -> pick(PICK_SOURCE));
        layout.addView(src);

        Button dst = new Button(this);
        dst.setText("Выбрать папку назначения");
        dst.setOnClickListener(v -> pick(PICK_DEST));
        layout.addView(dst);

        Button copy = new Button(this);
        copy.setText("Копировать сейчас");
        copy.setOnClickListener(v -> copyNow());
        layout.addView(copy);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, 22, 0, 0);
        layout.addView(status);
        refreshStatus();

        ScrollView scroll = new ScrollView(this);
        scroll.addView(layout);
        setContentView(scroll);
    }

    private Uri readUri(String key) {
        String s = prefs.getString(key, null);
        return s == null ? null : Uri.parse(s);
    }

    private void pick(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                   Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, req);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (result != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
        if (req == PICK_SOURCE) {
            sourceUri = uri;
            prefs.edit().putString("source", uri.toString()).apply();
        } else if (req == PICK_DEST) {
            destUri = uri;
            prefs.edit().putString("dest", uri.toString()).apply();
        }
        refreshStatus();
    }

    private void refreshStatus() {
        if (status == null) return;
        status.setText("Источник: " + (sourceUri == null ? "не выбран" : sourceUri.toString()) +
            "\n\nНазначение: " + (destUri == null ? "не выбрано" : destUri.toString()));
    }

    private void copyNow() {
        if (sourceUri == null || destUri == null) {
            Toast.makeText(this, "Сначала выбери источник и назначение", Toast.LENGTH_LONG).show();
            return;
        }
        status.setText("Копирование…");
        new Thread(() -> {
            try {
                DocumentFile src = DocumentFile.fromTreeUri(this, sourceUri);
                DocumentFile dst = DocumentFile.fromTreeUri(this, destUri);
                if (src == null || dst == null || !src.canRead() || !dst.canWrite())
                    throw new IOException("Нет доступа к выбранной папке. Выбери её заново.");
                int[] count = new int[]{0};
                copyTree(src, dst, count);
                runOnUiThread(() -> status.setText("Готово. Файлов скопировано: " + count[0] +
                    "\n\nСуществующие файлы перезаписываются. Папки с одинаковыми именами объединяются."));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Ошибка: " + e.getMessage()));
            }
        }).start();
    }

    private void copyTree(DocumentFile src, DocumentFile dst, int[] count) throws IOException {
        for (DocumentFile item : src.listFiles()) {
            if (item.getName() == null) continue;
            if (item.isDirectory()) {
                DocumentFile child = dst.findFile(item.getName());
                if (child == null || !child.isDirectory()) {
                    if (child != null) child.delete();
                    child = dst.createDirectory(item.getName());
                }
                if (child == null) throw new IOException("Не удалось создать папку: " + item.getName());
                copyTree(item, child, count);
            } else if (item.isFile()) {
                DocumentFile target = dst.findFile(item.getName());
                if (target != null) target.delete();
                target = dst.createFile(item.getType() == null ? "application/octet-stream" : item.getType(), item.getName());
                if (target == null) throw new IOException("Не удалось создать файл: " + item.getName());
                try (InputStream in = getContentResolver().openInputStream(item.getUri());
                     OutputStream out = getContentResolver().openOutputStream(target.getUri(), "w")) {
                    if (in == null || out == null) throw new IOException("Не удалось открыть файл: " + item.getName());
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                count[0]++;
            }
        }
    }
}
